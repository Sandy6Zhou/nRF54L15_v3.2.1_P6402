/**\
 * Copyright (c) 2024 Bosch Sensortec GmbH. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 **/

/******************************************************************************/
/*!                 Header Files                                              */
#include <stdio.h>
#include "bmi325.h"
#include "common.h"

/******************************************************************************/
/*!         Static Function Declaration                                       */

/*!
 *  @brief This internal API is used to set configurations for no-motion.
 *
 *  @param[in] dev       : Structure instance of bmi3_dev.
 *
 *  @return Status of execution.
 */
static int8_t set_feature_config(struct bmi3_dev *dev);

/******************************************************************************/
/*!               Functions                                                   */

/* This function starts the execution of program. */
int main(void)
{
    /* Status of API are returned to this variable. */
    int8_t rslt;

    /* Variable to get no-motion interrupt status. */
    uint16_t int_status = 0;

    /* Sensor initialization configuration. */
    struct bmi3_dev dev = { 0 };

    /* Feature enable initialization. */
    struct bmi3_feature_enable feature = { 0 };

    /* Interrupt mapping structure. */
    struct bmi3_map_int map_int = { 0 };

    /* Function to select interface between SPI and I2C, according to that the device structure gets updated.
     * Interface reference is given as a parameter
     * For I2C : BMI3_I2C_INTF
     * For SPI : BMI3_SPI_INTF
     */
    rslt = bmi3_interface_init(&dev, BMI3_SPI_INTF);
    bmi3_error_codes_print_result("bmi3_interface_init", rslt);

    if (rslt == BMI325_OK)
    {
        /* Initialize bmi325. */
        rslt = bmi325_init(&dev);
        bmi3_error_codes_print_result("bmi325_init", rslt);

        if (rslt == BMI325_OK)
        {
            /* Set feature configurations for no-motion. */
            rslt = set_feature_config(&dev);

            if (rslt == BMI325_OK)
            {
                feature.no_motion_x_en = BMI325_ENABLE;
                feature.no_motion_y_en = BMI325_ENABLE;
                feature.no_motion_z_en = BMI325_ENABLE;

                /* Enable the selected sensors. */
                rslt = bmi325_select_sensor(&feature, &dev);
                bmi3_error_codes_print_result("Sensor enable", rslt);

                if (rslt == BMI325_OK)
                {
                    map_int.no_motion_out = BMI3_INT1;

                    /* Map the feature interrupt for no-motion. */
                    rslt = bmi325_map_interrupt(map_int, &dev);
                    bmi3_error_codes_print_result("Map interrupt", rslt);
                    printf("Do not move the board\n");

                    /* Loop to get no-motion interrupt. */
                    do
                    {
                        /* Clear buffer. */
                        int_status = 0;

                        /* To get the interrupt status of no-motion. */
                        rslt = bmi325_get_int1_status(&int_status, &dev);
                        bmi3_error_codes_print_result("Get interrupt status", rslt);

                        /* To check the interrupt status of no-motion. */
                        if (int_status & BMI3_INT_STATUS_NO_MOTION)
                        {
                            printf("No-motion interrupt is generated\n");
                            break;
                        }
                    } while (rslt == BMI325_OK);
                }
            }
        }
    }

    bmi3_coines_deinit();

    return rslt;
}

/*!
 * @brief This internal API is used to set configurations for no-motion.
 */
static int8_t set_feature_config(struct bmi3_dev *dev)
{
    /* Status of API are returned to this variable. */
    int8_t rslt;

    /* Structure to define the type of sensor and its configurations. */
    struct bmi3_sens_config config[2] = { { 0 } };

    /* Configure the type of feature. */
    config[0].type = BMI325_ACCEL;
    config[1].type = BMI325_NO_MOTION;

    /* Get default configurations for the type of feature selected. */
    rslt = bmi325_get_sensor_config(config, 2, dev);
    bmi3_error_codes_print_result("Get sensor config", rslt);

    if (rslt == BMI325_OK)
    {
        /* Enable accel by selecting the mode. */
        config[0].cfg.acc.acc_mode = BMI3_ACC_MODE_NORMAL;

        /* Minimum slope of acceleration signal for motion detection. Range = 0 to 4095. */
        config[1].cfg.no_motion.slope_thres = 9;

        /* Hysteresis for the slope of the acceleration signal. Range = 0 to 1023. */
        config[1].cfg.no_motion.hysteresis = 5;

        /* Minimum duration for which the slope shall be greater than threshold for motion detection.
         * Range = 0 to 8191. */
        config[1].cfg.no_motion.duration = 9;

        /* Mode of the acceleration reference update. Range = 0 to 1.
         * Value    Name    Description
         *  0      OnEvent   On detection of the event
         *  1      Always    On update of acceleration signal
         */
        config[1].cfg.no_motion.acc_ref_up = 1;

        /* Wait time for clearing the event after slope is below threshold. Range = 0 to 7. */
        config[1].cfg.no_motion.wait_time = 5;

        /* Set new configurations. */
        rslt = bmi325_set_sensor_config(config, 2, dev);
        bmi3_error_codes_print_result("Set sensor config", rslt);
    }

    return rslt;
}
