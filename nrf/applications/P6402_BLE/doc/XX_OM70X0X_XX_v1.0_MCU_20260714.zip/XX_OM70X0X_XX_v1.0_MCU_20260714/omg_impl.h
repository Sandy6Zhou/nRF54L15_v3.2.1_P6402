#ifndef __OMG_IMPL_H__
#define __OMG_IMPL_H__
/**
 * @file omg_impl.h
 * @brief Platform glue for the OMG battery fuel-gauge driver.
 *
 * This header provides platform-specific hooks (I2C, delay, optional logging) and is
 * intended to be included only by omg_battery.c.
 */

#include "omg_battery.h"
#include "i2c_ex.h"  			// Replace with your platform I2C read/write header
#include "co_delay.h"          	// Replace with your platform delay header

/********************************************************************************************/
/* 						        APIs to be implemented							            */	
/********************************************************************************************/
static int _omg_read_byte(const omg_uint8_t addr, omg_uint8_t* ret_data)
{
	return volt01_i2c_read(addr, 1, ret_data);     // Replace with your platform I2C read function
}

static int _omg_read_word(const omg_uint8_t addr, omg_uint16_t* ret_data)
{
	omg_uint8_t tmp_data[2];
	int ret = volt01_i2c_read(addr, 2, tmp_data);  // Replace with your platform I2C read function
	if(ret < 0)
	{
		return OMG_ERROR_IIC;
	}
	
	*ret_data = ((omg_uint16_t)tmp_data[0] << 8) | tmp_data[1];
	return OMG_ERROR_NONE;
}

static int _omg_write_byte(const omg_uint8_t addr, const omg_uint8_t data)
{
	return volt01_i2c_write(addr, &data, 1);   // Replace with your platform I2C write function
}

static int _omg_write_word(const omg_uint8_t addr, const omg_uint16_t data)
{
	omg_uint8_t tmp_data[2];
	tmp_data[0] = (data >> 8) & 0xFF;
	tmp_data[1] = data & 0xFF;
	
	int ret = volt01_i2c_write(addr, tmp_data, 2);   // Replace with your platform I2C write function
	if(ret < 0)
	{
		return OMG_ERROR_IIC;
	}
	
	return OMG_ERROR_NONE;
}

static void _omg_delay_ms(const omg_uint32_t ms)
{
	co_delay_ms(ms);	// Replace with your platform delay function
}

#if (OMG_ENABLE_SOC_COMPENSATION_RELAX_ANTI)
/**
 * @brief Get charge status
 * @return true if charging; false otherwise
 */
static omg_bool_t _omg_get_charge_status()
{
#error "Please implement _omg_get_charge_status function to get charge status from your system"
	return omg_false;
}
#endif

#if OMG_ENABLE_LOG_FEATURE
#include <stdio.h>              // Only needed for this example build; remove in real application

#define OMG_LOG_LEVEL_NONE 	0
#define OMG_LOG_LEVEL_ERROR	1
#define OMG_LOG_LEVEL_WARN 	2
#define OMG_LOG_LEVEL_INFO 	3
#define OMG_LOG_LEVEL_DEBUG	4

#define OMG_LOG_LEVEL OMG_LOG_LEVEL_DEBUG

/**
 * @brief Internal logging helper. Do not call directly.
 *
 * `_omg_printf()` is the low-level output hook. Replace it with your platform's raw
 * logging function if needed.
 *
 * Newline is not appended automatically. Include `\n` explicitly in the format string
 * when you want a line break.
 */
#define _omg_printf(...)  printf(__VA_ARGS__)
#define _omg_log_print(level_str, fmt, arg...)                             \
	do {                                                                     \
		_omg_printf("[OMG %s: %s-%d] " fmt, level_str, __FUNCTION__ ,__LINE__,##arg); \
	} while (0)

#ifndef _omg_log_error
#if OMG_LOG_LEVEL >= OMG_LOG_LEVEL_ERROR
#define _omg_log_error(fmt, arg...) _omg_log_print("E", fmt, ##arg)
#else
#define _omg_log_error(fmt, arg...) do { } while (0)
#endif
#endif

#ifndef _omg_log_warn
#if OMG_LOG_LEVEL >= OMG_LOG_LEVEL_WARN
#define _omg_log_warn(fmt, arg...) _omg_log_print("W", fmt, ##arg)
#else
#define _omg_log_warn(fmt, arg...)  do { } while (0)
#endif
#endif

#ifndef _omg_log_info
#if OMG_LOG_LEVEL >= OMG_LOG_LEVEL_INFO
#define _omg_log_info(fmt, arg...) _omg_log_print("I", fmt, ##arg)
#else
#define _omg_log_info(fmt, arg...)  do { } while (0)
#endif
#endif

#ifndef _omg_log_debug
#if OMG_LOG_LEVEL >= OMG_LOG_LEVEL_DEBUG
#define _omg_log_debug(fmt, arg...) _omg_log_print("D", fmt, ##arg)
#else
#define _omg_log_debug(fmt, arg...) do { } while (0)
#endif
#endif

#else  /* !OMG_ENABLE_LOG_FEATURE */

#define _omg_log_error(fmt, arg...) do { } while (0)
#define _omg_log_warn(fmt, arg...)  do { } while (0)
#define _omg_log_info(fmt, arg...)  do { } while (0)
#define _omg_log_debug(fmt, arg...) do { } while (0)

#endif /* OMG_ENABLE_LOG_FEATURE */

#endif // __OMG_IMPL_H__