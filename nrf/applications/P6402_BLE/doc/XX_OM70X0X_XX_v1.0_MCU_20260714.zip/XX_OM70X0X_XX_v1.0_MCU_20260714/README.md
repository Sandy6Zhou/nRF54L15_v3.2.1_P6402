OM70X0X电量计驱动使用说明
=================================

# 目录
- [简介](#简介)
- [交付文件清单](#交付文件清单)
- [适用芯片](#适用芯片)
- [移植指南](#移植指南)
	- [MCU平台](#MCU平台)
	- [Linux驱动集成](#Linux驱动集成)
- [配置项与可选功能](#配置项与可选功能)
- [电池Profile与参数适配](#电池Profile与参数适配)
- [API说明及对外接口](#API说明及对外接口)
- [运行要点与注意事项](#运行要点与注意事项)
- [常见问题FAQ](#常见问题FAQ)



# 简介
本文档面向使用 OM70X0X 系列电量计芯片的客户，说明驱动的交付内容、移植与配置方法、以及典型的调用方式。驱动支持通过 I2C 读取电压、电流、温度、SOC、SOH、Cycle cnt 等信息，并提供可选功能（SOC 补偿、满充状态保持、温度补偿等）。


# 交付文件清单
--------------------

- MCU 驱动（参考实现，便于直接集成至您的 MCU 工程）
	- omg_battery.c / omg_battery.h：电池 Profile、参数与阈值配置（需与电池型号适配）
	- omg_impl.h: 平台相关接口实现（I2C 读写与延时）
	- omg_test.c：基础功能示例代码

- Linux 驱动（单文件交付，已包含完整逻辑）
	- omg_battery_linux.c：面向 Linux 内核的电量计驱动，包括电池 Profile、寄存器配置与 power_supply 属性上报，无需额外依赖文件。


# 适用芯片
------------------

- OM7010X（电压型）
- OM7020X（电压电流型）

默认示例以 OM7020X 为目标（参见 `omg_battery.h` 中 `OMG_DRIVER_VERSION_STRING`）。

# 移植指南
## MCU平台
--------------------

1) 硬件连接
- I2C 7-bit 从地址：0x38（默认地址）（请按原理图接线，确保上拉与电源时序）
2) 平台接口封装（位于 `omg_impl.h`）
	- `#include "i2c_ex.h"`：替换为您的平台 I2C 读写封装头文件
	- `#include "co_delay.h"`：替换为您的平台毫秒级延时头文件
	- 需要在客户平台实现或映射以下 3 个接口（函数名保持一致，或在本驱动内做同名封装）：
	- `int volt01_i2c_read(uint8_t reg, uint8_t len, uint8_t* buf);`
	- `int volt01_i2c_write(uint8_t reg, const uint8_t* data, uint8_t len);`
	- `void co_delay_ms(uint32_t ms);`

3) 关键宏配置（位于 `omg_battery.h`）
	- `OMG_USER_SENSING`：电流采样电阻（mΩ），仅 OM7020X(电流型) 使用，例如 10 表示 10 mΩ
	- `OMG_USER_VOLTAGE_MULTIPLE`：电压分压倍率，电池与VCELL分压关系，例如 两串电池时，电池对地：VCELL对地=3:1，分压则填 3；单串电池不用分压填 1
	- `OMG_USER_USE_TEMP_SOURCE_TYPE`：温度来源
		`OMG_INTERNAL_TEMP`: 电量计内部温度传感器
		`OMG_EXTERNAL_NTC_TEMP`: 外部 NTC 温度
		`OMG_USE_HOST_TEMP`: 主控得到的温度数据传入电量计；如果不调用`omg_set_temp()`默认25℃
	- `OMG_USE_SOH_HOST`：是否由主控维护 SOH 与循环次数，默认打开

4) 开发阶段调用流程（推荐顺序）
- 上电后调用 `omg_init()` 完成芯片初始化与 Profile 设置
- 若温度来源为`OMG_USE_HOST_TEMP`，在初始化后调用一次 `omg_set_temp()` 注入当前温度
- 调用`omg_update_log`来获取最新的电量计数据和打印日志（包含电压、电流、温度、SOC等调试数据）


5) 产品阶段调用流程（推荐顺序）
- 上电后调用 `omg_init()` 完成芯片初始化与 Profile 设置
- 若温度来源为`OMG_USE_HOST_TEMP`，在初始化后调用一次 `omg_set_temp()` 注入当前温度
- 轮询读取建议顺序：电压/电流/温度 → 最后读取 `omg_get_soc()`（SOC 依赖前述量）

6) I2C/时序注意
- 初始化后首次有效数据（电压/电流/SOC）准备需要约 70~100 ms，驱动内部已做等待
- I2C 建议 100 kHz ~ 400 kHz，确保上拉与电源稳定后再访问寄存器

## Linux驱动集成
------------------------

- 交付文件：`omg_battery_linux.c`
- 特点：已包含电池 Profile、寄存器配置与 power_supply 属性上报，无需额外依赖文件。
- 集成要点：
	- 将该文件加入您的内核驱动目录或外置模块工程；
	- 在设备树/板级文件中为 I2C 设备绑定匹配的 compatible 信息（文件内提供 of_device_id）；
	- 使用 Kbuild/Kconfig 方式编译为内核内置或模块（示例：obj-m += omg_battery_linux.o）。

设备树示例：
```dts
omfgu@38 {
    compatible = "onmicro,fgu";
    reg = <0x38>;
    status = "okay";
};
```


# 配置项与可选功能
------------------

位于 `omg_battery.h` 的开关项：

- 功能使能
	- `OMG_ENABLE_CURRENT_OFFSET`：电流零偏矫正(弃用)
	- `OMG_ENABLE_GET_CUR_SUB_OFFSET`：读电流时自动减去零偏项（弃用）
	- `OMG_ENABLE_SOC_COMPENSATION`：SOC 补偿（减缓松弛/充电拐点影响）
	- `OMG_ENABLE_FULL_SET_CHARGE_DETECTION`：满电状态保持
	- `OMG_ENABLE_CUR_ADJUST_PROFILE`: 按电流档位动态调整电池 Profile
	- `OMG_ENABLE_SOC_COMPENSATION_RELAX_ANTI_JUMP`: SOC 补偿时启用松弛与抗跳变逻辑(用于电压型电量计)
	- `OMG_ENABLE_CHARGE_ADJUST_PROFILE`: 按充电状态动态调整电池 Profile(用于电压型电量计)
- 温度补偿
	- `OM_ENABLE_NTC_TEMP_COMPENSATION`：分段线性温度补偿（针对外部 NTC）
- Log 调试输出
	- `OMG_ENABLE_LOG_FEATURE`：开启调试日志打印（需实现 `omg_impl.h`中的日志hook）
	- `OMG_ENABLE_DUMP`： 开启寄存器 Dump 功能（调试用）


# 电池Profile与参数适配
----------------------

- 在 `omg_battery.c` 中维护电池 Profile 与参数（例如曲线、门限、分段系数等），需按电池型号标定。
- 关键结构（示例）
	- `ChargeEndPointParamType`：充满判据、充放电步进等
	- `CurAdjustParamType`：按电流阈值选择寄存器组
	- `g_OMFuelgauge_param.profileData`：将预设的电池建模（曲线）配置对写入电量计芯片

温度补偿（可选）
----------------

- `omg_battery.c` 中提供分段线性函数 `omg_temp_fixed()`，由下列宏定义系数：
	- `TEMP_FIXED_KEY{0..3}`：分段拐点（°C）
	- `TEMP_FIXED_GAIN{0..4}`、`TEMP_FIXED_OFFSET{0..4}`：各段斜率与偏置
- 标定方法：在若干温箱点采集“环境温度 vs 读数”，回推原始温度后拟合更新 GAIN/OFFSET，重编译验证偏差


SOC 补偿与满充状态保持（可选）
--------------------------

- SOC 补偿：当 `OMG_ENABLE_SOC_COMPENSATION=1` 时，驱动会结合电流、电压在高 SOC 段做平滑/限制，降低松弛与拐点导致的跳变。
- 满充状态保持：当 `OMG_ENABLE_FULL_SET_CHARGE_DETECTION=1` 时，在 SOC=100% 辅助关闭/打开基于电流的充电检测位，避免满充状态抖动。


# API说明及对外接口
-------------------

初始化与电源：
- `int omg_init(void);`
- `int omg_sleep(void);`
- `int omg_active(void);`

基础读写：
- `int omg_get_id(omg_uint8_t* id);`          // 芯片 ID 校验
- `int omg_get_vol(omg_uint16_t* vol);`       // mV; 获得电池电压数据
- `int omg_get_temp(omg_int8_t* temp);`       // °C; 获得电池温度数据
- `int omg_get_soc(omg_uint8_t* soc);`        // %; 获得电池soc数据

仅 OM7020X：
- `int omg_get_cur(omg_int16_t* cur);`        // mA; 获得电池电流数据  
- `int omg_get_soh(omg_uint8_t* soh);`        //  获得电池健康度
- `int omg_get_cycle_cnt(omg_uint16_t* cnt);` //  获得电池使用次数
- `int omg_set_soh(omg_uint8_t soh);`         //  获得电池健康度
- `int omg_set_cycle_cnt(omg_uint16_t cnt);`  //  获得电池使用次数
- `int omg_set_soh_by_cycle_cnt(omg_uint16_t cnt);`（当 `OMG_USE_SOH_HOST=1` 时）
主控注入温度（当 `OMG_USE_TEMP_SOURCE_TYPE=OMG_USE_HOST_TEMP`）：
- `int omg_set_temp(const omg_int8_t temp);`

调用建议（轮询示例）：
1. `omg_get_vol()` → 2. `omg_get_cur()` → 3. `omg_get_temp()` → 4. `omg_get_soc()`


错误码
------

- `OMG_ERROR_NONE`：成功
- `OMG_ERROR_IIC`：I2C 读写失败
- `OMG_ERROR_CHIP_ID`：芯片 ID 不匹配
- `OMG_ERROR_NO_PROFILE`：缺少电池 Profile
- `OMG_ERROR_OTHER`：其他错误

# 运行要点与注意事项
------------------

1) 休眠与掉电
- Sleep 模式不丢寄存器，唤醒后通常无需重新写入 Profile；
- 掉电会使得寄存器丢失，需在重新上电后调用 `omg_init()` 重写 Profile；


2) 读取顺序
- 为保证 SOC 计算准确，建议“电压/电流/温度先读，SOC 最后读”。


# 常见问题FAQ
---------------

Q：没有电量计没有接外部温度传感器时如何处理？
A：将 `OMG_USER_USE_TEMP_SOURCE_TYPE` 如果对电量计精度要求不高，可以使用内部温度。建议使用主控向电量计注入温度。