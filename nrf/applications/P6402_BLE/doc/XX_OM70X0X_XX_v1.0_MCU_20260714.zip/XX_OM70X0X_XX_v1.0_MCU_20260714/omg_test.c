#include "omg_battery.h"
#include "i2c_ex.h"
#include "peripheral.h"


static co_timer_t simple_timer;
static void simple_timer_handler(co_timer_t *timer, void *param)
{
	omg_update_log();
}

void omg_test()
{
	volt01_i2c_init();
	omg_init();
	
	co_timer_set(&simple_timer, 10 * 1000, TIMER_REPEAT, simple_timer_handler, NULL);	//10s 
}
